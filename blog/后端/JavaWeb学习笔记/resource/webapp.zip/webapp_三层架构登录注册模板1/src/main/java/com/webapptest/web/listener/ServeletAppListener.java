package com.webapptest.web.listener;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

@WebListener // 记得加注解
public class ServeletAppListener implements ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        System.out.println("ServeletApp启动了......");
    }
    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        System.out.println("ServeletApp关闭了......");
    }
}
