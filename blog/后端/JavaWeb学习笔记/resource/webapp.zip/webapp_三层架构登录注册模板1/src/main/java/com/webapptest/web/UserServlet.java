package com.webapptest.web;

import java.io.IOException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;
import com.webapptest.database.pojo.User;
import com.webapptest.service.UserService;
import com.webapptest.utils.CheckCodeUtil;

// 当浏览器访问 /api/user/login 时，
// 会由 BaseServlet 的 service 函数 找到子类的 login 这个函数,然后执行他
@WebServlet("/api/user/*")
public class UserServlet extends BaseServlet{
    UserService userService = new UserService(); // 服务层
    public void login(HttpServletRequest request,HttpServletResponse response ) throws IOException{

        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=utf-8");
        
        String username = request.getParameter("username");
        String password = request.getParameter("password");
     
        // 调用服务层，检查用户存在
        User user = userService.checkUserExist(username, password);

        ResponseData responseData = new ResponseData();
        if(user!=null){
            responseData.setStatus(1);
            responseData.setMsg("登录成功!");
            user.setPassword(null);// 清除密码信息
            responseData.setData(user);// 把user对象传递过去
        }
        else{
            responseData.setStatus(0);
            responseData.setMsg("登录失败!");
        }
        response.getWriter().write(JSON.toJSONString(responseData));// 响应数据

        System.out.println("UserServlet的login被调用了");
    }
    // 获取注册用户时需要的验证码图片
    public void getVerifytImage(HttpServletRequest request,HttpServletResponse response) throws IOException{
        // 生成5位的随机验证码，并保存到session中
        String VarifyCode = CheckCodeUtil.generateVerifyCode(5);
        request.getSession().setAttribute("VarifyCode", VarifyCode);
        // 生成图片返回给浏览器
        CheckCodeUtil.outputImage(200, 50, response.getOutputStream(), VarifyCode);
        System.out.println("UserServlet的getVerifytImage被调用了");
    }
    // 注册用户
    public void register(HttpServletRequest request,HttpServletResponse response) throws IOException{
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=utf-8");
        
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String VarifyCode = request.getParameter("VarifyCode"); // 从浏览器得到的VarifyCode
        String VarifyCode_inSession = (String) request.getSession().getAttribute("VarifyCode");// 从session中获得的VarifyCode

        User user = new User();
        user.setUsername(username);
        user.setPassword(password);

        ResponseData responseData = new ResponseData();

        if( VarifyCode.equalsIgnoreCase(VarifyCode_inSession) == false) // 忽略大小写的比对
        {
            responseData.setStatus(1);
            responseData.setMsg("注册失败!,验证码错误。");
            response.getWriter().write(JSON.toJSONString(responseData));
            return;
        }

        Boolean result = userService.addUser(user);

        if(result){
            responseData.setStatus(1);
            responseData.setMsg("注册成功!");
        }
        else{
            responseData.setStatus(0);
            responseData.setMsg("注册失败!");
        }
        response.getWriter().write(JSON.toJSONString(responseData));
    
        System.out.println("UserServlet的register被调用了");
    }
    private class ResponseData{
        int status;
        String msg;
        Object data;
        public int getStatus() {
            return status;
        }
        public void setStatus(int status) {
            this.status = status;
        }
        public String getMsg() {
            return msg;
        }
        public void setMsg(String msg) {
            this.msg = msg;
        }
        public Object getData() {
            return data;
        }
        public void setData(Object data) {
            this.data = data;
        }
        
    } 
}