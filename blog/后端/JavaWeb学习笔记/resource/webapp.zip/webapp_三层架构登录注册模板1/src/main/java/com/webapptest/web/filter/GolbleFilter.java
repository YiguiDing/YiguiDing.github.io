// package com.webapptest.web.filter;

// import java.io.IOException;
// import javax.servlet.Filter;
// import javax.servlet.FilterChain;
// import javax.servlet.FilterConfig;
// import javax.servlet.ServletException;
// import javax.servlet.ServletRequest;
// import javax.servlet.ServletResponse;
// import javax.servlet.annotation.WebFilter;
// // import javax.servlet.http.HttpServletRequest;
// // import javax.servlet.http.HttpServletResponse;

// @WebFilter("/login")
// public class GolbleFilter implements Filter {
//     @Override
//     public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
//     throws IOException, ServletException
//     {
//         // HttpServletRequest httpServletRequest = (HttpServletRequest)request;

//         // 1.放行前，对request中的数据进行预处理
//         // 此处可对 httpServletRequest 处理

//         // 2. 放行，转交给下一个过滤器，如果已经是最后一个过滤器，则交给实际的Servlet的处理函数
//         chain.doFilter(request, response);

//         // HttpServletResponse httpServletResponse = (HttpServletResponse)response;
//         // 3. 此时拿到的 response 是经过 过滤器和实际Servlet处理函数处理过的response
//         // 此处可对 httpServletResponse 处理
//     }
//     @Override
//     public void destroy() {
//     }
//     @Override
//     public void init(FilterConfig filterConfig) throws ServletException {
//     }
// }
