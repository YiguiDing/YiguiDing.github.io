package com.webapptest.database.mapper;
import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.webapptest.database.pojo.User;

public interface UserMapper {

    List<User> selectAll();
    
    User selectUserById(int id);

    @Select("select * from tb_user where username = #{username} and password = #{password};")
    User selectUserByUsernameAndPassword(
        @Param("username") String username,
        @Param("password") String password
    );

    @Insert("INSERT INTO tb_user(id,username,password) values(null,#{username},#{password});")
    int addUser(User user);
}