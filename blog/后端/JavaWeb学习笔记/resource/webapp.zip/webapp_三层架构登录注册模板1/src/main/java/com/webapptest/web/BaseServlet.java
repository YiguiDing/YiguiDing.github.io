package com.webapptest.web;

import java.lang.reflect.Method;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class BaseServlet extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) {
        String uriString = req.getRequestURI(); // 获取URI: /user/login
        int supliceIndex = uriString.lastIndexOf("/"); // 找到最后一个/符号的位置
        String methodName = uriString.substring(supliceIndex+1); //获取方法名: login

        try {// 通过反射获取这个方法,并执行这个方法
            Method method = this.getClass().getDeclaredMethod(methodName,HttpServletRequest.class,HttpServletResponse.class);
            method.invoke(this, req,resp);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("BaseServlet的service被调用了");
    }
}
