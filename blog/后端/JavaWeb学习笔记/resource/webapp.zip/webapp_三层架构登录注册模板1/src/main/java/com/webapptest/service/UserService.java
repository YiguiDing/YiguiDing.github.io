package com.webapptest.service;

import org.apache.ibatis.session.SqlSession;

import com.webapptest.database.DBSessionPool;
import com.webapptest.database.mapper.UserMapper;
import com.webapptest.database.pojo.User;

public class UserService {
    SqlSession session = DBSessionPool.getSqlSessionFactory().openSession(false); // 获取sqlSession

    // 添加用户
    public boolean addUser(User user){
        UserMapper userMapper = session.getMapper(UserMapper.class);
        int affectedRows=0;
        try {
            affectedRows = userMapper.addUser(user);
            if(affectedRows == 1) {
                session.commit(); // 提交事务
                return true;
            }else{
                session.rollback();// 回滚事务
                return false;
            }
        } catch (Exception e) {
            session.rollback();// 回滚事务
            return false;
        } finally {
            session.close();
        }
    }
    public User checkUserExist(String username,String password){// 检查用户是否存在
        UserMapper userMapper = session.getMapper(UserMapper.class);
        return userMapper.selectUserByUsernameAndPassword(username,password);
    }
}
