import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import com.webapptest.mapper.UserMapper;
import com.webapptest.pojo.User;
public class testUserMapper {
    @Test
    public static void testUserMapperselectAll() throws IOException{
        // 加载mybatis核心配置文件
        String resource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);

        // 获取SqlSession，用其来执行sql语句
        SqlSession session = sqlSessionFactory.openSession();
        // 获取UserMapper接口的代理对象
        UserMapper userMapper = session.getMapper(UserMapper.class);
        List<User> users = userMapper.selectAll();

        System.out.println(users);
    }
    public static void testUserMapperselectUserById() throws IOException{
        // 加载mybatis核心配置文件
        String resource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);

        // 获取SqlSession，用其来执行sql语句
        SqlSession session = sqlSessionFactory.openSession();
        // 获取UserMapper接口的代理对象
        UserMapper userMapper = session.getMapper(UserMapper.class);
        User user = userMapper.selectUserById(1);

        System.out.println(user);
    }
}


